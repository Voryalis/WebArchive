(function(){
  const file = (location.pathname.split("/").pop() || "index.html").toLowerCase();
  const map = { "index.html":"01", "links.html":"02", "chat.html":"03" };
  const cur = map[file] || "01";

  document.querySelectorAll(".tabBtn").forEach(a=>{
    if (a.dataset.page === cur) a.classList.add("active");
  });

  const cpuEl = document.querySelector("[data-cpu]");
  const slideEl = document.querySelector("[data-slide]");
  const timeEl = document.querySelector("[data-time]");

  function tick(){
    if (cpuEl) cpuEl.textContent = `${Math.floor(8 + Math.random()*20)}%`;
    if (slideEl) slideEl.textContent = cur;
    if (timeEl) timeEl.textContent = new Date().toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"});
  }
  tick();
  setInterval(tick, 2500);
})();
