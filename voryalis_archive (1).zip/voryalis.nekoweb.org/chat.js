// voryalis chat — Firebase Realtime Database (anonymous auth)
// Drop-in for static sites (Nekoweb/Neocities)

const FIREBASE_SCRIPTS = [
  "https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js",
  "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth-compat.js",
  "https://www.gstatic.com/firebasejs/10.12.2/firebase-database-compat.js"
];

function loadScript(src){
  return new Promise((res, rej)=>{
    const s = document.createElement("script");
    s.src = src;
    s.async = true;
    s.onload = res;
    s.onerror = () => rej(new Error("Failed to load: " + src));
    document.head.appendChild(s);
  });
}

(function(){
  // Only run on chat page (must have #chatLog)
  if (!document.getElementById("chatLog")) return;

  (async function init(){
    try{
      for (const src of FIREBASE_SCRIPTS) await loadScript(src);

      // ✅ Your Firebase config
      const firebaseConfig = {
        apiKey: "AIzaSyASPTszRJfNL0u6KjxnWzonj1DumgSmDck",
        authDomain: "chat-for-site-52edb.firebaseapp.com",
        databaseURL: "https://chat-for-site-52edb-default-rtdb.europe-west1.firebasedatabase.app",
        projectId: "chat-for-site-52edb",
        storageBucket: "chat-for-site-52edb.firebasestorage.app",
        messagingSenderId: "147919979693",
        appId: "1:147919979693:web:a15da816f67d8e47fdf224",
        measurementId: "G-PQBY0VCRZQ"
      };

      // Avoid double-init
      if (!firebase.apps.length) firebase.initializeApp(firebaseConfig);

      const auth = firebase.auth();
      const db = firebase.database();

      const els = {
        log: document.getElementById("chatLog"),
        nick: document.getElementById("nickname"),
        msg: document.getElementById("message"),
        send: document.getElementById("send"),
        loginAnon: document.getElementById("loginAnon"),
        logout: document.getElementById("logout"),
      };

      // Defensive: ensure elements exist
      for (const [k, el] of Object.entries(els)){
        if (!el) throw new Error(`Missing element with id="${k === "log" ? "chatLog" : k}"`);
      }

      // Load saved nickname
      els.nick.value = localStorage.getItem("voryalis_nick") || "";
      els.nick.addEventListener("input", () => {
        localStorage.setItem("voryalis_nick", els.nick.value.trim());
      });

      function fmtTime(ts){
        try{
          return new Date(ts).toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"});
        }catch{
          return "";
        }
      }

      function addLine(nick, text, ts){
        const p = document.createElement("p");
        // ✅ use msgLine (your CSS already has .msgLine)
        p.className = "msgLine";

        const time = ts ? fmtTime(ts) : "";
        p.innerHTML =
          `<span class="nick">${escapeHtml(nick || "anon")}</span> ` +
          `<span style="opacity:.65">${escapeHtml(time)}</span><br>` +
          `${escapeHtml(text)}`;

        els.log.appendChild(p);
        els.log.scrollTop = els.log.scrollHeight;
      }

      // Realtime listener (last 80)
      const ref = db.ref("messages").limitToLast(80);

      // Optional: clear log on refresh so it doesn't duplicate visually
      // (Firebase will repopulate the last 80)
      els.log.innerHTML = "";

      ref.on("child_added", snap => {
        const m = snap.val();
        if (!m) return;
        addLine(m.nick, m.text, m.ts);
      });

      els.loginAnon.addEventListener("click", async () => {
        try{
          await auth.signInAnonymously();
          addLine("system", "logged in ✔", Date.now());
        }catch(e){
          addLine("system", `login error: ${e.message}`, Date.now());
        }
      });

      els.logout.addEventListener("click", async () => {
        try{
          await auth.signOut();
          addLine("system", "logged out", Date.now());
        }catch(e){
          addLine("system", `logout error: ${e.message}`, Date.now());
        }
      });

      async function send(){
        const user = auth.currentUser;
        const nick = (els.nick.value || "").trim();
        const text = (els.msg.value || "").trim();

        if (!user){
          addLine("system", "login first (button below)", Date.now());
          return;
        }
        if (!nick){
          addLine("system", "set a nickname first", Date.now());
          return;
        }
        if (!text) return;

        await db.ref("messages").push({
          uid: user.uid,
          nick,
          text,
          ts: Date.now()
        });

        els.msg.value = "";
        els.msg.focus();
      }

      els.send.addEventListener("click", send);
      els.msg.addEventListener("keydown", (e)=>{
        if (e.key === "Enter") send();
      });

      auth.onAuthStateChanged(u=>{
        if (u) addLine("system", "auth: ok", Date.now());
        else addLine("system", "auth: none", Date.now());
      });

      function escapeHtml(s){
        return String(s).replace(/[&<>"']/g, (c)=>({
          "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
        }[c]));
      }

    }catch(err){
      // If Firebase CDN fails or IDs don't match, show it in the chat box
      const log = document.getElementById("chatLog");
      if (log){
        const p = document.createElement("p");
        p.className = "msgLine";
        p.textContent = "system: " + (err?.message || String(err));
        log.appendChild(p);
      }
      console.error(err);
    }
  })();
})();
